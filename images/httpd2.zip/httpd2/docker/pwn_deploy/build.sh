docker build -t "httpd2" .
